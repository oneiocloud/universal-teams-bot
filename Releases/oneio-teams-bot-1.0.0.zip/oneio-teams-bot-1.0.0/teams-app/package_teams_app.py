#!/usr/bin/env python3
"""Build the Teams app package from manifest.template.json.

Uses the same variable names as the App Service, so the manifest and the
running bot always point at the same app registration.

Usage:
  python package_teams_app.py --app-id <guid> --domain <bot>.azurewebsites.net
  # or via env vars:
  MicrosoftAppId=<guid> MICROSOFT_APP_DOMAIN=<host> python package_teams_app.py

Output: oneio-teams-bot.zip (manifest.json + color.png + outline.png),
ready to upload in Teams Admin Center or Teams > Apps > Upload a custom app.
"""
import argparse
import json
import os
import re
import sys
import uuid
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE / "manifest.template.json"
ICONS = ("color.png", "outline.png")
PLACEHOLDER = re.compile(r"\{\{([A-Z0-9_]+)\}\}")


def parse_args():
    p = argparse.ArgumentParser(description="Build ONEiO Teams app package")
    p.add_argument("--app-id", default=os.environ.get("MicrosoftAppId"),
                   help="App registration client ID (same as MicrosoftAppId)")
    p.add_argument("--domain", default=os.environ.get("MICROSOFT_APP_DOMAIN"),
                   help="Bot host, e.g. bot-esp-oneio-teams.azurewebsites.net")
    p.add_argument("--version", default=os.environ.get("APP_VERSION", "1.0.0"),
                   help="Manifest version; bump on every re-upload")
    p.add_argument("--out", default="oneio-teams-bot.zip")
    return p.parse_args()


def main():
    a = parse_args()

    if not a.app_id:
        sys.exit("Missing app ID: pass --app-id or set MicrosoftAppId")
    try:
        app_id = str(uuid.UUID(a.app_id))
    except ValueError:
        sys.exit(f"App ID is not a GUID: {a.app_id}")

    if not a.domain:
        sys.exit("Missing domain: pass --domain or set MICROSOFT_APP_DOMAIN")
    domain = re.sub(r"^https?://", "", a.domain).strip("/")

    if not re.fullmatch(r"\d+\.\d+\.\d+", a.version):
        sys.exit(f"Version must be semver x.y.z: {a.version}")

    values = {
        "MICROSOFT_APP_ID": app_id,
        "MICROSOFT_APP_DOMAIN": domain,
        "APP_VERSION": a.version,
    }

    template = TEMPLATE.read_text(encoding="utf-8")
    missing = set(PLACEHOLDER.findall(template)) - values.keys()
    if missing:
        sys.exit(f"Unresolved placeholders: {', '.join(sorted(missing))}")

    manifest = PLACEHOLDER.sub(lambda m: values[m.group(1)], template)
    json.loads(manifest)  # fail fast on broken JSON

    for icon in ICONS:
        if not (HERE / icon).is_file():
            sys.exit(f"Missing icon: {icon} (expected next to this script)")

    out = Path(a.out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", manifest)
        for icon in ICONS:
            z.write(HERE / icon, icon)

    print(f"Built {out} (app id {app_id}, version {a.version}, domain {domain})")


if __name__ == "__main__":
    main()
