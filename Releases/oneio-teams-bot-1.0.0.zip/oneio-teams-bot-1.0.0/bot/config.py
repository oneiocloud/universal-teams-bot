"""Runtime configuration, read from App Service environment variables."""
import os


class DefaultConfig:
    PORT = int(os.environ.get("PORT", 8000))

    # Bot identity. APP_TYPE: SingleTenant (app registration + secret)
    # or UserAssignedMSI (user-assigned managed identity, no secret).
    APP_ID = os.environ.get("MicrosoftAppId", "")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "")
    APP_TYPE = os.environ.get("MicrosoftAppType", "SingleTenant")
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "")

    # ONEiO outbound (bot -> ONEiO)
    ONEIO_URL = os.environ.get("ONEIO_URL", "")
    ONEIO_USERNAME = os.environ.get("ONEIO_USERNAME", "")
    ONEIO_PASSWORD = os.environ.get("ONEIO_PASSWORD", "")
    ONEIO_TIMEOUT_SECONDS = float(os.environ.get("ONEIO_TIMEOUT_SECONDS", "10"))

    # ONEiO inbound (ONEiO -> /api/send_card), sent in the X-API-Key header
    ONEIO_INBOUND_KEY = os.environ.get("ONEIO_INBOUND_KEY", "")

    # /home is persistent on Linux App Service; the app folder is not.
    STORAGE_PATH = os.environ.get(
        "STORAGE_PATH",
        "/home/data/storage.json" if os.environ.get("WEBSITE_SITE_NAME") else "storage.json",
    )

    @classmethod
    def missing(cls):
        """Return names of required settings that are not set."""
        required = {
            "MicrosoftAppId": cls.APP_ID,
            "MicrosoftAppTenantId": cls.APP_TENANTID,
            "ONEIO_URL": cls.ONEIO_URL,
            "ONEIO_USERNAME": cls.ONEIO_USERNAME,
            "ONEIO_PASSWORD": cls.ONEIO_PASSWORD,
            "ONEIO_INBOUND_KEY": cls.ONEIO_INBOUND_KEY,
        }
        if cls.APP_TYPE.lower() == "singletenant":
            required["MicrosoftAppPassword"] = cls.APP_PASSWORD
        return [k for k, v in required.items() if not v]
