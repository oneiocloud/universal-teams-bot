"""Ticket context storage: ticket_id -> conversation reference + card activity id.

Stored as JSON on persistent storage (STORAGE_PATH, default /home/data on App Service).
Writes are atomic. Designed for a single App Service instance; for scale-out,
replace with Azure Table Storage or Cosmos DB.
"""
import json
import logging
import os
import tempfile
import threading

from config import DefaultConfig

STORAGE_PATH = DefaultConfig.STORAGE_PATH
_lock = threading.Lock()
logger = logging.getLogger("storage")


def _read() -> dict:
    if not os.path.exists(STORAGE_PATH):
        return {}
    try:
        with open(STORAGE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        logger.error("Storage file %s is corrupt; starting with empty context", STORAGE_PATH)
        return {}


def _write(data: dict) -> None:
    directory = os.path.dirname(os.path.abspath(STORAGE_PATH))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".storage-", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, STORAGE_PATH)


def save_ticket_context(ticket_id: str, conversation_reference, activity_id: str) -> None:
    ticket_id = str(ticket_id)
    with _lock:
        data = _read()
        data[ticket_id] = {
            "conversation_reference": conversation_reference.serialize(),
            "activity_id": activity_id,
        }
        _write(data)
    logger.info("Saved context for ticket_id=%s", ticket_id)


def get_ticket_context(ticket_id: str):
    with _lock:
        context = _read().get(str(ticket_id))
    if not context:
        logger.warning("No context found for ticket_id=%s", ticket_id)
    return context


def get_ticket_id_by_activity(activity_id: str):
    with _lock:
        data = _read()
    for ticket_id, context in data.items():
        if context.get("activity_id") == activity_id:
            return ticket_id
    return None
