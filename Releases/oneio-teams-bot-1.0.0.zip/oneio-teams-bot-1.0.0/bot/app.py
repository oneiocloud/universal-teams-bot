# app.py
import hmac
import logging
import sys

from aiohttp import web
from botbuilder.core import TurnContext
from botbuilder.integration.aiohttp import (
    CloudAdapter,
    ConfigurationBotFrameworkAuthentication,
)
from botbuilder.schema import Activity, ActivityTypes, Attachment, ConversationReference

from card_validator import validate_card
from config import DefaultConfig
from storage_utils import get_ticket_context
from universal_bot import UniversalBot

CONFIG = DefaultConfig()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("teamsbot")

_missing = CONFIG.missing()
if _missing:
    # Fail fast with a readable message instead of an auth error on first message.
    logger.critical("Missing required app settings: %s", ", ".join(_missing))
    sys.exit(1)

if CONFIG.APP_TYPE.lower() == "multitenant":
    logger.warning("MicrosoftAppType=MultiTenant: tokens are requested from the botframework.com tenant. "
                   "Use SingleTenant or UserAssignedMSI for customer-hosted bots.")

ADAPTER = CloudAdapter(ConfigurationBotFrameworkAuthentication(CONFIG))
BOT = UniversalBot(CONFIG)


async def on_error(context: TurnContext, error: Exception):
    logger.exception("Unhandled bot error: %s", error)
    try:
        await context.send_activity("The bot encountered an error. Please try again.")
    except Exception:  # noqa: BLE001
        logger.warning("Could not send error message to user")


ADAPTER.on_turn_error = on_error


# Teams -> bot (authenticated by the Bot Framework adapter)
async def messages(req: web.Request) -> web.Response:
    return await ADAPTER.process(req, BOT)


# ONEiO -> bot: replace the card of an existing ticket conversation
async def send_card(req: web.Request) -> web.Response:
    supplied = req.headers.get("X-API-Key", "")
    if not hmac.compare_digest(supplied.encode(), CONFIG.ONEIO_INBOUND_KEY.encode()):
        logger.warning("Rejected /api/send_card call: invalid or missing X-API-Key")
        return web.json_response({"error": "Unauthorized"}, status=401)

    try:
        payload = await req.json()
    except Exception:  # noqa: BLE001
        return web.json_response({"error": "Body must be JSON"}, status=400)

    ticket_id = payload.get("ticket_id")
    card = payload.get("card")
    if not ticket_id or not card:
        return web.json_response({"error": "Missing ticket_id or card"}, status=400)

    try:
        validate_card(card)
    except ValueError as e:
        return web.json_response({"error": str(e)}, status=400)

    ticket_context = get_ticket_context(ticket_id)
    if not ticket_context:
        return web.json_response({"error": f"Ticket context for ticket {ticket_id} not found"}, status=404)

    conversation_reference = ConversationReference().deserialize(ticket_context.get("conversation_reference"))
    activity_id = ticket_context.get("activity_id")
    if not conversation_reference or not activity_id:
        return web.json_response({"error": f"Conversation reference or activity ID for ticket {ticket_id} missing"}, status=404)

    async def continue_callback(turn_context: TurnContext):
        await turn_context.update_activity(
            Activity(
                type=ActivityTypes.message,
                id=activity_id,
                attachments=[Attachment(content_type="application/vnd.microsoft.card.adaptive", content=card)],
            )
        )

    try:
        await ADAPTER.continue_conversation(conversation_reference, continue_callback, CONFIG.APP_ID)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to update card for ticket %s", ticket_id)
        return web.json_response({"error": "Failed to update card in Teams"}, status=502)

    logger.info("Card updated for ticket %s", ticket_id)
    return web.json_response({"message": "Card updated"}, status=200)


# App Service health check
async def health(_req: web.Request) -> web.Response:
    return web.json_response({"status": "ok"})


def create_app() -> web.Application:
    app = web.Application()
    app.router.add_post("/api/messages", messages)
    app.router.add_post("/api/send_card", send_card)
    app.router.add_get("/health", health)
    return app


app = create_app()

if __name__ == "__main__":
    logger.info("Starting ONEiO Teams Bot on port %s (app type %s)", CONFIG.PORT, CONFIG.APP_TYPE)
    web.run_app(app, host="0.0.0.0", port=CONFIG.PORT)
