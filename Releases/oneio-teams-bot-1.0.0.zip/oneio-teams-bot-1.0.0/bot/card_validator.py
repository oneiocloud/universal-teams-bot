"""Validate Adaptive Cards against the bundled schema (no runtime download)."""
import json
from pathlib import Path

from jsonschema import ValidationError, validate

_SCHEMA_PATH = Path(__file__).resolve().parent / "adaptive_card_schema.json"
_schema_cache = None


def _load_schema():
    global _schema_cache
    if _schema_cache is None:
        with open(_SCHEMA_PATH, "r", encoding="utf-8") as f:
            _schema_cache = json.load(f)
    return _schema_cache


def validate_card(card_json: dict) -> bool:
    try:
        validate(instance=card_json, schema=_load_schema())
        return True
    except ValidationError as e:
        raise ValueError(f"Invalid Adaptive Card: {e.message}") from e
