import asyncio
import datetime
import logging
import re

import requests
from requests.auth import HTTPBasicAuth
from botbuilder.core import ActivityHandler, TurnContext
from botbuilder.schema import Activity, Attachment, InvokeResponse

from storage_utils import save_ticket_context, get_ticket_id_by_activity

logger = logging.getLogger("universal_bot")
_AT_MENTION = re.compile(r"<at>.*?</at>", re.IGNORECASE | re.DOTALL)


def _invoke_message(status: int, text: str) -> InvokeResponse:
    """Universal Action (adaptiveCard/action) response in the format Teams expects."""
    return InvokeResponse(
        status=200,
        body={"statusCode": status, "type": "application/vnd.microsoft.activity.message", "value": text},
    )


class UniversalBot(ActivityHandler):
    def __init__(self, config):
        super().__init__()
        self._config = config

    async def on_message_activity(self, turn_context: TurnContext):
        if turn_context.activity.value:
            return await self._handle_card_action(turn_context)

        # In team and group chat scopes the text contains "<at>Bot name</at>"
        text = _AT_MENTION.sub("", turn_context.activity.text or "").strip().lower()
        if text == "create ticket":
            return await self._handle_create_ticket(turn_context)
        return await self._handle_invalid_message(turn_context)

    async def on_invoke_activity(self, turn_context: TurnContext) -> InvokeResponse:
        if turn_context.activity.name == "adaptiveCard/action":
            return await self._handle_card_action(turn_context)
        logger.warning("Unknown invoke activity: %s", turn_context.activity.name)
        return InvokeResponse(status=501)

    async def _handle_create_ticket(self, turn_context: TurnContext):
        ticket_id = generate_ticket_id()
        activity_id = await self._send_loading_card(turn_context, ticket_id, "Please wait while we prepare your form.")
        conversation_reference = TurnContext.get_conversation_reference(turn_context.activity)
        save_ticket_context(ticket_id, conversation_reference, activity_id)
        logger.info("Created ticket %s", ticket_id)
        try:
            await self._send_to_oneio({"verb": "ticket_created", "ticket_id": ticket_id})
        except Exception as e:  # noqa: BLE001
            logger.error("Failed to send ticket_created to ONEiO: %s", e)
            await turn_context.send_activity("Could not reach the ticketing service. Please try again later.")

    async def _handle_invalid_message(self, turn_context: TurnContext):
        await turn_context.send_activity("Say 'create ticket' to open a new ticket.")

    async def _handle_card_action(self, turn_context: TurnContext):
        activity = turn_context.activity
        logger.debug("Card action value: %s", activity.value)

        if activity.type == "invoke":  # Action.Execute
            action_value = activity.value.get("action", {}) or {}
            verb = action_value.get("verb") or action_value.get("action")
            static_data = action_value.get("data", {}) or activity.value.get("data", {}) or {}
            inputs = activity.value.get("inputs", {}) or {}
            datafields = {**static_data, **inputs}
        else:  # Action.Submit
            verb = activity.value.get("verb")
            datafields = activity.value or {}

        ticket_id = get_ticket_id_by_activity(activity.reply_to_id or activity.id)
        if not ticket_id:
            logger.error("No ticket_id found for activity %s", activity.reply_to_id or activity.id)
            if activity.type == "invoke":
                return _invoke_message(400, "Could not determine the ticket ID.")
            await turn_context.send_activity("Could not determine the ticket ID.")
            return None

        try:
            await self._send_loading_card(turn_context, ticket_id, "Updating ticket...")
        except Exception as e:  # noqa: BLE001
            logger.warning("Failed to show loading card: %s", e)

        user = activity.from_property
        payload = {
            "ticket_id": ticket_id,
            "verb": verb,
            "data": datafields,
            "user": user.as_dict() if hasattr(user, "as_dict") else vars(user),
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        logger.info("Card action verb=%s ticket=%s", verb, ticket_id)

        try:
            await self._send_to_oneio(payload)
        except Exception as e:  # noqa: BLE001
            logger.error("Failed to send card action to ONEiO: %s", e)
            if activity.type == "invoke":
                return _invoke_message(500, "An error occurred while processing your request.")
            await turn_context.send_activity("An error occurred while processing your request.")
            return None

        return _invoke_message(200, "Request sent.") if activity.type == "invoke" else None

    async def _send_to_oneio(self, payload: dict):
        # requests is blocking: run it off the event loop
        await asyncio.to_thread(send_to_oneio, payload, self._config)

    async def _send_loading_card(self, turn_context: TurnContext, ticket_id: str, description_text: str):
        card_content = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.6",
            "body": [
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "Image",
                                    "url": "https://cdn.prod.website-files.com/615862cf7e67455a772dfa12/674f00941f14b7062960bb98_ONEiO_Wordmark-comp_Accent_black-bluedot-small.png",
                                    "width": "50px",
                                    "height": "50px"
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "width": "stretch",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "ONEiO Teams Bot",
                                    "weight": "Bolder",
                                    "size": "Medium",
                                    "horizontalAlignment": "Center",
                                    "wrap": True
                                },
                                {
                                    "type": "TextBlock",
                                    "text": "Creating your ticket...",
                                    "horizontalAlignment": "Center",
                                    "spacing": "None",
                                    "isSubtle": True,
                                    "wrap": True
                                }
                            ],
                            "verticalContentAlignment": "Center"
                        }
                    ]
                },
                {
                    "type": "TextBlock",
                    "text": description_text,
                    "horizontalAlignment": "Center",
                    "wrap": True,
                    "spacing": "Medium"
                },
                {
                    "type": "TextBlock",
                    "text": "Loading...",
                    "weight": "Bolder",
                    "size": "Large",
                    "horizontalAlignment": "Center",
                    "spacing": "Medium"
                },
                {
                    "type": "Image",
                    "url": "https://usagif.com/wp-content/uploads/loading-96.gif",
                    "horizontalAlignment": "Center",
                    "size": "Small",
                    "spacing": "Small"
                },
                {
                    "type": "TextBlock",
                    "text": f"Ticket ID: {ticket_id}",
                    "isSubtle": True,
                    "spacing": "Small",
                    "horizontalAlignment": "Center",
                    "wrap": True
                }
            ]
        }
        card_attachment = Attachment(
            content_type="application/vnd.microsoft.card.adaptive",
            content=card_content
        )
        if turn_context.activity.reply_to_id:
            sent_activity = await turn_context.update_activity(
                Activity(
                    id=turn_context.activity.reply_to_id,
                    type="message",
                    attachments=[card_attachment],
                    conversation=turn_context.activity.conversation
                )
            )
        else:
            sent_activity = await turn_context.send_activity(
                Activity(
                    type="message",
                    attachments=[card_attachment]
                )
            )
        logger.debug("Displayed loading card in chat")
        return sent_activity.id if sent_activity and sent_activity.id else turn_context.activity.reply_to_id



def send_to_oneio(payload: dict, config) -> None:
    if not (config.ONEIO_URL and config.ONEIO_USERNAME and config.ONEIO_PASSWORD):
        raise ValueError("ONEIO_URL, ONEIO_USERNAME or ONEIO_PASSWORD not set")
    response = requests.post(
        config.ONEIO_URL,
        json=payload,
        auth=HTTPBasicAuth(config.ONEIO_USERNAME, config.ONEIO_PASSWORD),
        timeout=config.ONEIO_TIMEOUT_SECONDS,
    )
    logger.info("ONEiO responded %s", response.status_code)
    response.raise_for_status()


def generate_ticket_id() -> str:
    return str(int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000))
