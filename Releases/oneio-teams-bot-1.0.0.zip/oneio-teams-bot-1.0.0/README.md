# ONEiO Teams Bot 1.0.0 - installation package

Installation guide: "ONEiO Teams Bot - Installation Guide" (provided by ONEiO).

## Contents

- `deploy/deploy.sh`  Deployment script for Azure Cloud Shell (Bash)
- `bot/`              Bot source code (Python 3.11)
- `dist/bot.zip`      Prebuilt bot code for manual deployment (guide, Appendix A)
- `teams-app/`        Teams app manifest template, icons and packaging script

## Quick start (Azure Cloud Shell, Bash)

    cd ~
    unzip -o oneio-teams-bot-1.0.0.zip -d oneio-teams-bot && cd oneio-teams-bot
    az account set --subscription "<subscription name or ID>"
    RESOURCE_GROUP=rg-oneio-teams-bot LOCATION=uksouth NAME_PREFIX=oneio-teams-bot \
    APP_SERVICE_SKU=B1 bash deploy/deploy.sh

The script asks for the ONEiO endpoint URL, username and password, shows a
summary to confirm, and ends with the values to give to ONEiO. The Teams app
package is written to `build/oneio-teams-bot-app.zip`.

The script is safe to run again with the same values. Options:

- `ROTATE_SECRET=true`       renew the client secret
- `ROTATE_INBOUND_KEY=true`  replace the inbound key (give the new key to ONEiO)
- `SECRET_YEARS=1`           client secret lifetime in years

Support: contact ONEiO with the Microsoft App ID and the time of the problem.
