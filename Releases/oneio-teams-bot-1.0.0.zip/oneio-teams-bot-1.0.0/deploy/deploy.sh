#!/usr/bin/env bash
# ONEiO Teams Bot - deployment for Azure Cloud Shell (Bash)
#
# Creates or updates, in the signed-in subscription and tenant:
#   - bot identity: single-tenant app registration + client secret (AUTH_MODE=secret)
#                   or user-assigned managed identity (AUTH_MODE=msi)
#   - App Service plan (Linux) + Web App (Python 3.11) running the bot code
#   - Azure Bot resource with the Microsoft Teams channel
#   - Teams app package (build/oneio-teams-bot-app.zip)
#
# Safe to re-run: existing resources are reused, settings are re-applied and the
# code is redeployed. The client secret and inbound key are kept unless
# ROTATE_SECRET=true / ROTATE_INBOUND_KEY=true.
#
# Usage (from the package root):
#   az account set --subscription "<subscription name or id>"
#   RESOURCE_GROUP=rg-oneio-teams-bot LOCATION=northeurope NAME_PREFIX=oneio-teams-bot \
#     bash deploy/deploy.sh
set -euo pipefail

# ---------------------------------------------------------------------------
# Customer values (override via environment variables)
# ---------------------------------------------------------------------------
RESOURCE_GROUP="${RESOURCE_GROUP:-rg-oneio-teams-bot}"
LOCATION="${LOCATION:-northeurope}"
NAME_PREFIX="${NAME_PREFIX:-oneio-teams-bot}"
AUTH_MODE="${AUTH_MODE:-secret}"            # secret | msi
APP_SERVICE_SKU="${APP_SERVICE_SKU:-B1}"    # B1 or higher
SECRET_YEARS="${SECRET_YEARS:-1}"
APP_VERSION="${APP_VERSION:-1.0.0}"         # Teams app version; bump on re-upload
ROTATE_SECRET="${ROTATE_SECRET:-false}"
ROTATE_INBOUND_KEY="${ROTATE_INBOUND_KEY:-false}"

# ONEiO values: prompted for when not set
ONEIO_URL="${ONEIO_URL:-}"
ONEIO_USERNAME="${ONEIO_USERNAME:-}"
ONEIO_PASSWORD="${ONEIO_PASSWORD:-}"

# ---------------------------------------------------------------------------
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build"

log()  { printf '\n==> %s\n' "$*"; }
fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

retry() {  # retry <attempts> <sleep-seconds> <command...>
  local n="$1" s="$2"; shift 2
  local i
  for ((i = 1; i <= n; i++)); do
    if "$@"; then return 0; fi
    [[ $i -lt $n ]] && { echo "   retrying in ${s}s ($i/$n)..."; sleep "$s"; }
  done
  return 1
}

# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------
[[ -d "$ROOT/bot" && -d "$ROOT/teams-app" ]] || fail "Run from the unzipped package (bot/ and teams-app/ not found)."
[[ "$NAME_PREFIX" =~ ^[a-z0-9-]{3,20}$ ]] || fail "NAME_PREFIX must be 3-20 lowercase letters, digits or hyphens."
[[ "$AUTH_MODE" == "secret" || "$AUTH_MODE" == "msi" ]] || fail "AUTH_MODE must be 'secret' or 'msi'."
APP_SERVICE_SKU="${APP_SERVICE_SKU^^}"
[[ "$APP_SERVICE_SKU" != "F1" && "$APP_SERVICE_SKU" != "FREE" ]] || \
  fail "The Free (F1) plan is not supported for production. Use APP_SERVICE_SKU=B1 or higher."
FREE_TIER="false"
command -v az >/dev/null || fail "Azure CLI not found. Use Azure Cloud Shell (Bash)."
command -v zip >/dev/null || fail "zip not found."

az account show >/dev/null 2>&1 || fail "Not signed in. Run 'az login'."
SUBSCRIPTION_ID="$(az account show --query id -o tsv)"
TENANT_ID="$(az account show --query tenantId -o tsv)"
SUBSCRIPTION_NAME="$(az account show --query name -o tsv)"

# Stable, globally unique suffix for the web app and bot names
SUFFIX="$(printf '%s' "$SUBSCRIPTION_ID/$RESOURCE_GROUP/$NAME_PREFIX" | sha256sum | cut -c1-6)"
APP_NAME="${NAME_PREFIX}-${SUFFIX}"
PLAN_NAME="${NAME_PREFIX}-plan"
IDENTITY_NAME="${NAME_PREFIX}-id"

existing_setting() {
  az webapp config appsettings list -g "$RESOURCE_GROUP" -n "$APP_NAME" \
    --query "[?name=='$1'].value | [0]" -o tsv 2>/dev/null || true
}

if az webapp show -g "$RESOURCE_GROUP" -n "$APP_NAME" -o none 2>/dev/null; then
  echo "Existing deployment found: $APP_NAME. Reusing its ONEiO settings unless overridden."
  [[ -n "$ONEIO_URL" ]] || ONEIO_URL="$(existing_setting ONEIO_URL)"
  [[ -n "$ONEIO_USERNAME" ]] || ONEIO_USERNAME="$(existing_setting ONEIO_USERNAME)"
  [[ -n "$ONEIO_PASSWORD" ]] || ONEIO_PASSWORD="$(existing_setting ONEIO_PASSWORD)"
fi

[[ -n "$ONEIO_URL" ]] || read -r -p "ONEiO endpoint URL (from ONEiO): " ONEIO_URL
[[ -n "$ONEIO_USERNAME" ]] || read -r -p "ONEiO username (from ONEiO): " ONEIO_USERNAME
[[ -n "$ONEIO_PASSWORD" ]] || { read -r -s -p "ONEiO password (from ONEiO): " ONEIO_PASSWORD; echo; }
[[ "$ONEIO_URL" =~ ^https:// ]] || fail "ONEIO_URL must start with https://"
[[ -n "$ONEIO_USERNAME" && -n "$ONEIO_PASSWORD" ]] || fail "ONEiO username and password are required."

cat <<EOF

Deploying ONEiO Teams Bot
  Subscription : $SUBSCRIPTION_NAME ($SUBSCRIPTION_ID)
  Tenant       : $TENANT_ID
  Resource grp : $RESOURCE_GROUP ($LOCATION)
  App / bot    : $APP_NAME
  Auth mode    : $AUTH_MODE
  Plan         : $APP_SERVICE_SKU
EOF
read -r -p "Continue? [y/N] " ok
[[ "$ok" =~ ^[Yy]$ ]] || exit 0

# ---------------------------------------------------------------------------
# 0. Resource providers
# ---------------------------------------------------------------------------
log "Resource providers"
PROVIDERS=(Microsoft.Web Microsoft.BotService)
[[ "$AUTH_MODE" == "msi" ]] && PROVIDERS+=(Microsoft.ManagedIdentity)
for ns in "${PROVIDERS[@]}"; do
  state="$(az provider show -n "$ns" --query registrationState -o tsv 2>/dev/null || echo Unknown)"
  if [[ "$state" != "Registered" ]]; then
    echo "   registering $ns"
    az provider register -n "$ns" --wait -o none || \
      echo "   WARNING: could not register $ns. Ask a subscription owner to register it."
  fi
done

# ---------------------------------------------------------------------------
# 1. Resource group
# ---------------------------------------------------------------------------
log "Resource group"
az group create -n "$RESOURCE_GROUP" -l "$LOCATION" -o none

# ---------------------------------------------------------------------------
# 2. App Service plan + Web App
# ---------------------------------------------------------------------------
log "App Service plan ($APP_SERVICE_SKU, Linux)"
if ! az appservice plan show -g "$RESOURCE_GROUP" -n "$PLAN_NAME" -o none 2>/dev/null; then
  az appservice plan create -g "$RESOURCE_GROUP" -n "$PLAN_NAME" -l "$LOCATION" \
    --is-linux --sku "$APP_SERVICE_SKU" -o none
fi

log "Web App $APP_NAME"
if ! az webapp show -g "$RESOURCE_GROUP" -n "$APP_NAME" -o none 2>/dev/null; then
  az webapp create -g "$RESOURCE_GROUP" -p "$PLAN_NAME" -n "$APP_NAME" \
    --runtime "PYTHON:3.11" -o none
fi
APP_HOST="$(az webapp show -g "$RESOURCE_GROUP" -n "$APP_NAME" --query defaultHostName -o tsv)"
ENDPOINT="https://${APP_HOST}/api/messages"

# ---------------------------------------------------------------------------
# 3. Bot identity
# ---------------------------------------------------------------------------
APP_PASSWORD=""
MSI_RESOURCE_ID=""
if [[ "$AUTH_MODE" == "secret" ]]; then
  log "Entra app registration (single tenant)"
  APP_TYPE="SingleTenant"
  APP_ID="$(az ad app list --display-name "$APP_NAME" --query "[0].appId" -o tsv)"
  if [[ -z "$APP_ID" ]]; then
    APP_ID="$(az ad app create --display-name "$APP_NAME" --sign-in-audience AzureADMyOrg --query appId -o tsv)"
  fi
  if ! az ad sp show --id "$APP_ID" -o none 2>/dev/null; then
    retry 6 10 az ad sp create --id "$APP_ID" -o none || fail "Could not create service principal for $APP_ID"
  fi

  APP_PASSWORD="$(existing_setting MicrosoftAppPassword)"
  CURRENT_APP_ID="$(existing_setting MicrosoftAppId)"
  if [[ -z "$APP_PASSWORD" || "$CURRENT_APP_ID" != "$APP_ID" || "$ROTATE_SECRET" == "true" ]]; then
    log "Creating client secret (valid $SECRET_YEARS year(s))"
    APP_PASSWORD="$(az ad app credential reset --id "$APP_ID" --append \
      --display-name "oneio-teams-bot $(date +%F)" --years "$SECRET_YEARS" \
      --query password -o tsv)"
  else
    echo "   keeping existing client secret (ROTATE_SECRET=true to replace)"
  fi
else
  log "User-assigned managed identity"
  APP_TYPE="UserAssignedMSI"
  if ! az identity show -g "$RESOURCE_GROUP" -n "$IDENTITY_NAME" -o none 2>/dev/null; then
    az identity create -g "$RESOURCE_GROUP" -n "$IDENTITY_NAME" -l "$LOCATION" -o none
  fi
  APP_ID="$(az identity show -g "$RESOURCE_GROUP" -n "$IDENTITY_NAME" --query clientId -o tsv)"
  MSI_RESOURCE_ID="$(az identity show -g "$RESOURCE_GROUP" -n "$IDENTITY_NAME" --query id -o tsv)"
  az webapp identity assign -g "$RESOURCE_GROUP" -n "$APP_NAME" --identities "$MSI_RESOURCE_ID" -o none
fi

# ---------------------------------------------------------------------------
# 4. Web App hardening and settings
# ---------------------------------------------------------------------------
log "Web App configuration"
az webapp update -g "$RESOURCE_GROUP" -n "$APP_NAME" --https-only true -o none
if [[ "$FREE_TIER" == "true" ]]; then
  ALWAYS_ON="false"; HEALTH_CHECK_PATH=""      # neither is available on F1
else
  ALWAYS_ON="true";  HEALTH_CHECK_PATH="/health"
fi
az webapp config set -g "$RESOURCE_GROUP" -n "$APP_NAME" \
  --startup-file "python3 app.py" --always-on "$ALWAYS_ON" --ftps-state Disabled \
  --min-tls-version 1.2 --http20-enabled true -o none
az webapp config set -g "$RESOURCE_GROUP" -n "$APP_NAME" \
  --generic-configurations "{\"healthCheckPath\": \"$HEALTH_CHECK_PATH\"}" -o none
az webapp log config -g "$RESOURCE_GROUP" -n "$APP_NAME" \
  --docker-container-logging filesystem -o none

INBOUND_KEY="$(existing_setting ONEIO_INBOUND_KEY)"
if [[ -z "$INBOUND_KEY" || "$ROTATE_INBOUND_KEY" == "true" ]]; then
  INBOUND_KEY="$(openssl rand -hex 32)"
  INBOUND_KEY_CHANGED="yes"
else
  INBOUND_KEY_CHANGED="no"
fi

settings=(
  "MicrosoftAppId=$APP_ID"
  "MicrosoftAppTenantId=$TENANT_ID"
  "MicrosoftAppType=$APP_TYPE"
  "ONEIO_URL=$ONEIO_URL"
  "ONEIO_USERNAME=$ONEIO_USERNAME"
  "ONEIO_PASSWORD=$ONEIO_PASSWORD"
  "ONEIO_INBOUND_KEY=$INBOUND_KEY"
  "STORAGE_PATH=/home/data/storage.json"
  "SCM_DO_BUILD_DURING_DEPLOYMENT=true"
)
[[ "$AUTH_MODE" == "secret" ]] && settings+=("MicrosoftAppPassword=$APP_PASSWORD")
az webapp config appsettings set -g "$RESOURCE_GROUP" -n "$APP_NAME" --settings "${settings[@]}" -o none
if [[ "$AUTH_MODE" == "msi" ]]; then
  az webapp config appsettings delete -g "$RESOURCE_GROUP" -n "$APP_NAME" \
    --setting-names MicrosoftAppPassword -o none 2>/dev/null || true
fi

# ---------------------------------------------------------------------------
# 5. Deploy bot code
# ---------------------------------------------------------------------------
log "Deploying bot code (build runs on App Service, takes a few minutes)"
mkdir -p "$BUILD"
rm -f "$BUILD/bot.zip"
(cd "$ROOT/bot" && zip -qr "$BUILD/bot.zip" . -x '__pycache__/*' '*.pyc' 'storage.json' '.env')
az webapp deploy -g "$RESOURCE_GROUP" -n "$APP_NAME" --src-path "$BUILD/bot.zip" --type zip -o none

# ---------------------------------------------------------------------------
# 6. Azure Bot + Teams channel
# ---------------------------------------------------------------------------
log "Azure Bot $APP_NAME"
if az bot show -g "$RESOURCE_GROUP" -n "$APP_NAME" -o none 2>/dev/null; then
  az bot update -g "$RESOURCE_GROUP" -n "$APP_NAME" --endpoint "$ENDPOINT" -o none
else
  bot_args=(-g "$RESOURCE_GROUP" -n "$APP_NAME" --app-type "$APP_TYPE" --appid "$APP_ID"
            --tenant-id "$TENANT_ID" --endpoint "$ENDPOINT" --sku F0 -o none)
  [[ "$AUTH_MODE" == "msi" ]] && bot_args+=(--msi-resource-id "$MSI_RESOURCE_ID")
  retry 6 15 az bot create "${bot_args[@]}" || fail "Could not create Azure Bot"
fi

log "Microsoft Teams channel"
if ! az bot msteams show -g "$RESOURCE_GROUP" -n "$APP_NAME" -o none 2>/dev/null; then
  az bot msteams create -g "$RESOURCE_GROUP" -n "$APP_NAME" -o none
fi

# ---------------------------------------------------------------------------
# 7. Health check
# ---------------------------------------------------------------------------
# Smoke test of the /health endpoint. Works on every plan; separate from the
# App Service health check feature.
log "Waiting for https://$APP_HOST/health"
if ! retry 30 10 curl -fsS -o /dev/null "https://$APP_HOST/health"; then
  echo "   Health check did not respond. Check Log stream in the portal; startup errors"
  echo "   name any missing app setting."
fi

# ---------------------------------------------------------------------------
# 8. Teams app package
# ---------------------------------------------------------------------------
log "Teams app package"
python3 "$ROOT/teams-app/package_teams_app.py" \
  --app-id "$APP_ID" --domain "$APP_HOST" --version "$APP_VERSION" \
  --out "$BUILD/oneio-teams-bot-app.zip"

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
cat <<EOF

=============================================================================
 Deployment complete
=============================================================================
 Microsoft App ID     : $APP_ID
 Tenant ID            : $TENANT_ID
 App type             : $APP_TYPE
 Messaging endpoint   : $ENDPOINT
 Teams app package    : $BUILD/oneio-teams-bot-app.zip
                        (Cloud Shell: Manage files > Download)

 Send to ONEiO through a secure channel:
   Card update URL    : https://$APP_HOST/api/send_card
   Inbound key        : $INBOUND_KEY   (changed in this run: $INBOUND_KEY_CHANGED)

 Next: upload the Teams app package in Teams Admin Center.
EOF
if [[ "$AUTH_MODE" == "secret" ]]; then
  SECRET_END="$(az ad app credential list --id "$APP_ID" --query "max_by([], &endDateTime).endDateTime" -o tsv)"
  echo " Client secret expires: $SECRET_END  (re-run with ROTATE_SECRET=true before then)"
fi
